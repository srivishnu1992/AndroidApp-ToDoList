package com.example.to_dolist;

import android.os.Parcelable;

import java.io.Serializable;
import java.util.Date;

/**
 * Created by Navya on 2/3/2018.
 */

public class Task implements Serializable{
    String taskTitle;
    String Date;
    String time;
    int taskNum;
int priority;

    public Task(String taskTitle, String date, String time, int taskNum, int priority) {
        this.taskTitle = taskTitle;
        Date = date;
        this.time = time;
        this.taskNum = taskNum;

        this.priority = priority;
    }

    @Override
    public String toString() {
        return "Task{" +
                "taskTitle='" + taskTitle + '\'' +
                ", Date='" + Date + '\'' +
                ", time='" + time + '\'' +
                ", taskNum=" + taskNum +
                ", priority=" + priority +
                '}';
    }
}
