package com.example.to_dolist;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TimePicker;

import java.util.LinkedList;

public class CreateTaskActivity extends AppCompatActivity  {
String tasktitle;
    String taskdate;
    String tasktime;
    int totalTasknum;
    int selectedPriority;
    static final String CREATE_KEY="create";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_task);
        setTitle("Create Task");
        EditText title= findViewById(R.id.etTitle);
        EditText date= findViewById(R.id.etDate);
        EditText time= findViewById(R.id.etTime);
        tasktitle=title.getText().toString();
        taskdate=date.getText().toString();
        tasktime=time.getText().toString();
        RadioGroup priority=  findViewById(R.id.radioGroup);
        selectedPriority=priority.getCheckedRadioButtonId();

        if(getIntent()!=null&&getIntent().getExtras()!=null)
        {
            totalTasknum=(int) getIntent().getExtras().getSerializable((MainActivity.TASK_KEY));
        }
        findViewById(R.id.buttonSave).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Task task = new Task(tasktitle, taskdate, tasktime, totalTasknum++,selectedPriority);

                if (task != null) {
                    Intent intent = new Intent();
                    intent.putExtra(CREATE_KEY, task);
                    setResult(RESULT_OK,intent);
                }
                else
                {
                    setResult(RESULT_CANCELED);
                }
            }
        });
        findViewById(R.id.tvTaskdate).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                
            }
        });


    }


}
