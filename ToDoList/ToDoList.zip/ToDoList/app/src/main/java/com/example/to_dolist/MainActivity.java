package com.example.to_dolist;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.app.Activity;

import java.util.LinkedList;

public class MainActivity extends AppCompatActivity {

    static final int REQ_CODE=100;

    static final String TASK_KEY="task";
    LinkedList taskList=new LinkedList();
    int totalTasknum;
    TextView taskTitle;
    TextView taskDate;
    TextView taskTime;
    TextView index;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        taskTitle=(TextView) findViewById(R.id.tvTasktitle);
        taskDate=(TextView) findViewById(R.id.tvTaskdate);
        taskTime=(TextView) findViewById(R.id.tvTasktime);
        index=(TextView) findViewById(R.id.tvTaskpriority);


        ImageButton ibCreatetask= (ImageButton) findViewById(R.id.ibCreatetask);
        ibCreatetask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(MainActivity.this,CreateTaskActivity.class);
                startActivityForResult(intent,REQ_CODE);
                totalTasknum=taskList.size();
                intent.putExtra(TASK_KEY,totalTasknum);



            }
        });


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_CODE) {
            if (resultCode == RESULT_OK) {
                Task task = (Task) data.getExtras().getSerializable(CreateTaskActivity.CREATE_KEY);
                taskList.add(task);
                taskTitle.setText(task.taskTitle);
                taskDate.setText(task.Date);
                taskTime.setText(task.time);
                index.setText(task.taskNum+"of"+task.taskNum);



            }
        }


    }

}
