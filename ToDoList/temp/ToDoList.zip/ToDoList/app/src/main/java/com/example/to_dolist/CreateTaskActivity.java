package com.example.to_dolist;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.FragmentActivity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TimePicker;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.LinkedList;
import java.util.Locale;

public class CreateTaskActivity extends FragmentActivity  {
String tasktitle;
    String taskdate;
    String tasktime;
    int totalTasknum;
    String selectedPriority;

    EditText title;
    static EditText edate;
    static EditText etime;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        try {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_create_task);
            setTitle("Create Task");
            title = findViewById(R.id.etTitle);
            edate = findViewById(R.id.etDate);
            etime = findViewById(R.id.etTime);
            edate.setKeyListener(null);


            if (getIntent() != null && getIntent().getExtras() != null) {
                totalTasknum = (int) getIntent().getExtras().getSerializable((MainActivity.TASK_KEY));
            }
            findViewById(R.id.buttonSave).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    tasktitle = title.getText().toString();
                    taskdate = edate.getText().toString();
                    tasktime = etime.getText().toString();

                    if(tasktitle.equals(""))
                        title.setError("Please enter title");

                    if(taskdate.equals(""))
                        edate.setError("Please enter date");

                    if(tasktime.equals(""))
                        etime.setError("Please enter time");



                    RadioGroup priority = findViewById(R.id.radioGroup);

                    selectedPriority = ((RadioButton) findViewById(priority.getCheckedRadioButtonId())).getText().toString();
                    Task task= new Task(tasktitle, taskdate, tasktime, ++totalTasknum, selectedPriority);
                    Log.d("task", "onClick:" + task.toString());
                    if(tasktitle.equals("") || taskdate.equals("") || tasktime.equals("")) {
                        task = null;
                        --totalTasknum;
                    }

                    if (task != null) {
                        Intent intent = new Intent();
                        intent.putExtra(MainActivity.CREATE_KEY, task);
                        setResult(RESULT_OK, intent);
                        finish();
                    }
                   /* else {
                        setResult(RESULT_CANCELED);
                    } */

                }
            });
        }catch (Exception e) {
            Toast.makeText(getApplicationContext(), "Exception Occurred", Toast.LENGTH_SHORT).show();
        }
    }

        /*findViewById(R.id.tvTaskdate).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar newCalendar = Calendar.getInstance();
                datePickerDialog = new DatePickerDialog.OnDateSetListener() {

                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        Calendar newDate = Calendar.getInstance();
                        newDate.set(year, monthOfYear, dayOfMonth);
                        fromDateEtxt.setText(dateFormatter.format(newDate.getTime()));
                    }

                },newCalendar.get(Calendar.YEAR), newCalendar.get(Calendar.MONTH), newCalendar.get(Calendar.DAY_OF_MONTH));
                datePickerDialog.show();
            }
        });*/
        /*DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, month);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateLabel();
            }
        };*/
        /*@Override
        public void onClick(View v) {
            Log.d("VIEW",String.valueOf(v.getId()));
            if (v.getId()==R.id.etDate)
            {

                new DatePickerDialog(CreateTaskActivity.this, date, myCalendar
                        .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH)).show();
                Log.d("date","in the onclick");
            }
            if (v.getId()==R.id.etTime)
            {
                int hour = myCalendar.get(Calendar.HOUR_OF_DAY);
                int minute = myCalendar.get(Calendar.MINUTE);

                mTimePicker = new TimePickerDialog(CreateTaskActivity.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute) {
                        etime.setText( selectedHour + ":" + selectedMinute);
                    }
                }, hour, minute, true);
                mTimePicker.setTitle("Select Time");
                mTimePicker.show();
            }
            if(v.getId()==R.id.buttonSave)
            {
                tasktitle = title.getText().toString();
                taskdate = edate.getText().toString();
                tasktime = etime.getText().toString();
                RadioGroup priority = findViewById(R.id.radioGroup);
                selectedPriority = ((RadioButton) findViewById(priority.getCheckedRadioButtonId())).getText().toString();
                Task task = new Task(tasktitle, taskdate, tasktime, ++totalTasknum, selectedPriority);
                Log.d("task", "onClick:" + task.toString());
                if (task != null) {
                    Intent intent = new Intent();
                    intent.putExtra(MainActivity.CREATE_KEY, task);
                    setResult(RESULT_OK, intent);
                    finish();
                } else {
                    setResult(RESULT_CANCELED);
                }
            }
        }

        private void updateLabel(){
            String myFormat = "MM/dd/yy"; //In which you need put here
            SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
            edate.setText(sdf.format(myCalendar.getTime()));
        }

*/
        public static class DatePickerFragment extends DialogFragment
                implements DatePickerDialog.OnDateSetListener {

            @Override
            public Dialog onCreateDialog(Bundle savedInstanceState) {
                // Use the current date as the default date in the picker
                final Calendar c = Calendar.getInstance();
                int year = c.get(Calendar.YEAR);
                int month = c.get(Calendar.MONTH);
                int day = c.get(Calendar.DAY_OF_MONTH);

                // Create a new instance of DatePickerDialog and return it
                return new DatePickerDialog(getActivity(), this, year, month, day);
            }

            public void onDateSet(DatePicker view, int year, int month, int day) {
                edate.setText((month+1)+"/"+day+"/"+year);
            }
        }
    public void showDatePickerDialog(View v) {
        DialogFragment newFragment = new DatePickerFragment();
        newFragment.show(getSupportFragmentManager(), "datePicker");
    }
    public static class TimePickerFragment extends DialogFragment
            implements TimePickerDialog.OnTimeSetListener {

        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {
            // Use the current time as the default values for the picker
            final Calendar c = Calendar.getInstance();
            int hour = c.get(Calendar.HOUR_OF_DAY);
            int minute = c.get(Calendar.MINUTE);

            // Create a new instance of TimePickerDialog and return it
            return new TimePickerDialog(getActivity(), this, hour, minute,
                    DateFormat.is24HourFormat(getActivity()));
        }

        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {


            String timeSet = "";
            if (hourOfDay > 12) {
                hourOfDay -= 12;
                timeSet = "PM";
            } else if (hourOfDay == 0) {
                hourOfDay += 12;
                timeSet = "AM";
            } else if (hourOfDay == 12){
                timeSet = "PM";
            }else{
                timeSet = "AM";
            }

            String min = "";
            if (minute < 10)
                min = "0" + minute ;
            else
                min = String.valueOf(minute);

            // Append in a StringBuilder
            String aTime = new StringBuilder().append(hourOfDay).append(':')
                    .append(min ).append(" ").append(timeSet).toString();
            etime.setText(aTime);
        }

    }
    public void showTimePickerDialog(View v) {
        DialogFragment newFragment = new TimePickerFragment();
        newFragment.show(getSupportFragmentManager(), "timePicker");
    }

    }









