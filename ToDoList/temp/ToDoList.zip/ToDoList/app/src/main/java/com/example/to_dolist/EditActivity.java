package com.example.to_dolist;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class EditActivity extends AppCompatActivity {
    String tasktitle;
    String taskdate;
    String tasktime;
    int taskNum;
    String selectedPriority;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_task);
        setTitle("Edit Task");

        EditText title= findViewById(R.id.etTitle);
        EditText date= findViewById(R.id.etDate);
        EditText time= findViewById(R.id.etTime);

        RadioGroup priority=  findViewById(R.id.radioGroup);

        if(getIntent()!=null&&getIntent().getExtras()!=null)
        {
            Task task= (Task) getIntent().getExtras().getSerializable((MainActivity.TASK_KEY));
            title.setText(task.taskTitle);
            date.setText(task.Date);
            time.setText(task.time);
            taskNum=task.taskNum;
            Log.d("priority",task.priority);
            if(task.priority.equals("Low"))
            {
                priority.check(R.id.rbLow);
            }
            else if(task.priority.equals("Medium"))
            {
                priority.check(R.id.rbMedium);
                Log.d("priority",task.priority+"entered loop");
            }
            else if(task.priority.equals("high"))
            {
                priority.check(R.id.rbHigh);
            }
        }

        findViewById(R.id.buttonSave).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText title= findViewById(R.id.etTitle);
                EditText date= findViewById(R.id.etDate);
                EditText time= findViewById(R.id.etTime);
                tasktitle=title.getText().toString();
                taskdate=date.getText().toString();
                tasktime=time.getText().toString();

                if(tasktitle.equals(""))
                    title.setError("Please enter title");
                if(taskdate.equals(""))
                    date.setError("Please enter date");
                if(tasktime.equals(""))
                    time.setError("Please enter time");

                RadioGroup priority=  findViewById(R.id.radioGroup);
                selectedPriority= ((RadioButton) findViewById(priority.getCheckedRadioButtonId())).getText().toString();
                Task task = new Task(tasktitle, taskdate, tasktime, taskNum,selectedPriority);
                if(tasktitle.equals("") || taskdate.equals("") || tasktime.equals("")) {
                    task = null;
                }
                if(task!=null) {
                    Intent intent = new Intent();
                    intent.putExtra(MainActivity.EDIT_KEY, task);
                    setResult(RESULT_OK, intent);
                    finish();
                }
            }
        });
    }
}
